"""
Integration: Hotkey Listener + Thinking Orb
Connects Ctrl+F1 hotkey to spawn thinking orb overlay
"""

import threading
import time
from pynput import keyboard
from orb_overlay import ScreenOverlay, OrbState

class HotKeyOrbManager:
    """Manages hotkey-triggered thinking orb"""
    
    def __init__(self):
        self.overlay = None
        self.listener = None
        self.running = False
        self.overlay_thread = None
        
    def on_hotkey(self, key=None, state=OrbState.THINKING, duration=5):
        """
        Triggered when Ctrl+F1 is pressed
        Shows thinking orb for specified duration
        
        Args:
            key: keyboard key (from listener)
            state: What state to show (THINKING, LISTENING, ANALYZING)
            duration: How long to show orb (seconds)
        """
        print(f"✓ Hotkey triggered! Showing orb with state: {state.value}")
        
        # Create overlay
        self.overlay = ScreenOverlay(width=1920, height=1080)
        self.overlay.set_state(state)
        
        # Run in separate thread so main thread stays responsive
        self.overlay_thread = threading.Thread(
            target=self._show_overlay_for_duration,
            args=(duration,),
            daemon=True
        )
        self.overlay_thread.start()
    
    def _show_overlay_for_duration(self, duration):
        """Show overlay and close after duration"""
        try:
            # Note: This runs the pygame event loop which is blocking
            # For production, you might want to make this non-blocking
            self.overlay.show()
        except Exception as e:
            print(f"Error showing overlay: {e}")
        finally:
            self.overlay = None
    
    def show_thinking_orb(self, duration=3):
        """Show thinking orb (for Ctrl+F1 press)"""
        self.on_hotkey(state=OrbState.THINKING, duration=duration)
    
    def show_listening_orb(self, duration=3):
        """Show listening orb (while recording voice)"""
        if self.overlay:
            self.overlay.set_state(OrbState.LISTENING)
    
    def show_analyzing_orb(self, duration=2):
        """Show analyzing orb (while calling Gemini API)"""
        if self.overlay:
            self.overlay.set_state(OrbState.ANALYZING)
    
    def show_done_orb(self, duration=1):
        """Show done orb (briefly before closing)"""
        if self.overlay:
            self.overlay.set_state(OrbState.DONE)
    
    def close_overlay(self):
        """Close overlay if showing"""
        if self.overlay:
            self.overlay.close()
            self.overlay = None


class HotKeyListener:
    """Listen for Ctrl+F1 hotkey"""
    
    def __init__(self, orb_manager):
        self.orb_manager = orb_manager
        self.listener = None
        self.running = False
    
    def on_press(self, key):
        """Handle key press"""
        try:
            # Check for Ctrl+F1
            if hasattr(key, 'vk') and key.vk == 112:  # F1
                # Check if Ctrl is pressed
                if hasattr(key, 'ctrl') and key.ctrl:
                    self.orb_manager.show_thinking_orb(duration=5)
            
        except AttributeError:
            pass
        except Exception as e:
            print(f"Hotkey error: {e}")
    
    def on_release(self, key):
        """Handle key release"""
        try:
            # Stop listening for Alt+F1 (quit)
            if hasattr(key, 'vk') and key.vk == 113:  # F2
                if hasattr(key, 'alt') and key.alt:
                    self.stop()
        except:
            pass
    
    def start(self):
        """Start listening for hotkeys"""
        self.running = True
        self.listener = keyboard.Listener(
            on_press=self.on_press,
            on_release=self.on_release
        )
        self.listener.start()
        print("✓ Hotkey listener started (Ctrl+F1 to trigger orb)")
    
    def stop(self):
        """Stop listening"""
        self.running = False
        if self.listener:
            self.listener.stop()
        print("✗ Hotkey listener stopped")


def demo():
    """Demo: Show thinking orb with state transitions"""
    print("=" * 60)
    print("ScreenSense AI - Thinking Orb Demo")
    print("=" * 60)
    print()
    
    # Create manager and listener
    orb_mgr = HotKeyOrbManager()
    hotkey = HotKeyListener(orb_mgr)
    
    # Start listener
    hotkey.start()
    
    print("Press Ctrl+F1 to show thinking orb")
    print("Press Alt+F2 to quit")
    print()
    
    try:
        while hotkey.running:
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\n✓ Demo ended")
    finally:
        hotkey.stop()
        orb_mgr.close_overlay()


if __name__ == "__main__":
    demo()

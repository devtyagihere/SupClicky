"""
ScreenSense AI - Thinking Orb Overlay (60 FPS)
Animated glowing orb with particles and state transitions
Uses pygame for smooth 60 FPS animation
"""

import pygame
import math
import threading
import time
from enum import Enum

class OrbState(Enum):
    """Orb animation states"""
    THINKING = "thinking"
    LISTENING = "listening"
    ANALYZING = "analyzing"
    DONE = "done"

class Particle:
    """Single particle orbiting the orb"""
    def __init__(self, angle, distance, speed):
        self.angle = angle
        self.distance = distance
        self.speed = speed  # radians per frame
        self.life = 1.0  # alpha
        
    def update(self):
        self.angle += self.speed
        if self.angle > 2 * math.pi:
            self.angle -= 2 * math.pi
    
    def get_position(self, center_x, center_y):
        x = center_x + self.distance * math.cos(self.angle)
        y = center_y + self.distance * math.sin(self.angle)
        return int(x), int(y)

class ThinkingOrb:
    """60 FPS animated thinking orb"""
    
    def __init__(self, width=1920, height=1080):
        self.width = width
        self.height = height
        self.center_x = width // 2
        self.center_y = height // 2
        
        # Animation state
        self.frame = 0
        self.state = OrbState.THINKING
        self.running = False
        
        # Orb properties
        self.orb_radius = 75  # pixels
        self.min_radius = 60
        self.max_radius = 90
        self.rotation = 0
        self.pulse = 0
        self.glow_alpha = 1.0
        
        # Particles
        self.particles = []
        self.create_particles()
        
        # Colors (gradient)
        self.colors = [
            (0, 100, 255),      # Blue
            (100, 50, 255),     # Purple
            (0, 200, 255),      # Cyan
            (100, 100, 255),    # Light blue
        ]
        
        # FPS counter
        self.frame_count = 0
        self.fps_start = time.time()
        self.current_fps = 0
        
    def create_particles(self):
        """Create orbiting particles around orb"""
        self.particles = []
        num_particles = 12
        for i in range(num_particles):
            angle = (2 * math.pi * i) / num_particles
            distance = self.orb_radius + 50
            speed = 0.05 + (i % 3) * 0.01  # Varying speeds
            self.particles.append(Particle(angle, distance, speed))
    
    def update(self):
        """Update animation state"""
        self.frame += 1
        
        # Rotation: Full rotation every 2 seconds (120 frames at 60 FPS)
        self.rotation = (self.frame % 120) / 120 * (2 * math.pi)
        
        # Pulse: Oscillate between min and max radius
        self.pulse = math.sin(self.frame * 0.05) * (self.max_radius - self.min_radius) / 2
        self.orb_radius = (self.min_radius + self.max_radius) / 2 + self.pulse
        
        # Update particles
        for particle in self.particles:
            particle.update()
        
        # Glow pulsing
        self.glow_alpha = 0.5 + 0.5 * math.sin(self.frame * 0.03)
        
        # FPS calculation
        self.frame_count += 1
        elapsed = time.time() - self.fps_start
        if elapsed >= 1.0:
            self.current_fps = self.frame_count / elapsed
            self.frame_count = 0
            self.fps_start = time.time()
    
    def get_state_text(self):
        """Get text based on current state"""
        states = {
            OrbState.THINKING: "Thinking...",
            OrbState.LISTENING: "Listening...",
            OrbState.ANALYZING: "Analyzing...",
            OrbState.DONE: "Done!",
        }
        return states.get(self.state, "Processing...")
    
    def draw_to_surface(self, surface):
        """Draw orb directly to pygame surface"""
        center_x = surface.get_width() // 2
        center_y = surface.get_height() // 2
        
        # Draw outer glow rings
        glow_colors = [
            (20, 60, 150, int(50 * self.glow_alpha)),      # Dark blue glow
            (40, 100, 200, int(30 * self.glow_alpha)),     # Medium blue
            (60, 150, 255, int(15 * self.glow_alpha)),     # Light blue
        ]
        
        for i, (r, g, b, a) in enumerate(glow_colors):
            glow_size = int(self.orb_radius + (i + 1) * 20)
            pygame.draw.circle(
                surface,
                (r, g, b),
                (center_x, center_y),
                glow_size
            )
        
        # Draw main orb with gradient effect (concentric circles)
        for radius in range(int(self.orb_radius), 0, -2):
            # Color interpolation based on radius
            ratio = radius / self.orb_radius
            r = int(self.colors[0][0] * ratio + self.colors[1][0] * (1 - ratio))
            g = int(self.colors[0][1] * ratio + self.colors[2][1] * (1 - ratio))
            b = int(self.colors[0][2] * ratio + self.colors[3][2] * (1 - ratio))
            
            pygame.draw.circle(
                surface,
                (r, g, b),
                (center_x, center_y),
                radius
            )
        
        # Draw inner bright core
        core_size = int(self.orb_radius * 0.4)
        pygame.draw.circle(
            surface,
            (255, 255, 255),
            (center_x, center_y),
            core_size
        )
        
        # Draw particles
        for particle in self.particles:
            px, py = particle.get_position(center_x, center_y)
            pygame.draw.circle(
                surface,
                (100, 200, 255),
                (int(px), int(py)),
                3
            )

class ScreenOverlay:
    """Full-screen transparent overlay with thinking orb"""
    
    def __init__(self, width=1920, height=1080):
        pygame.init()
        self.width = width
        self.height = height
        self.orb = ThinkingOrb(width, height)
        self.running = False
        self.screen = None
        self.clock = pygame.time.Clock()
        self.font = None
        
    def create_overlay(self):
        """Create pygame window"""
        # Create display with transparency
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("ScreenSense AI - Thinking...")
        
        # Create font
        try:
            self.font = pygame.font.Font(None, 36)
        except:
            self.font = pygame.font.Font(None, 36)
        
    def animate(self):
        """Animation loop (60 FPS)"""
        self.running = True
        
        while self.running and self.screen:
            try:
                # Handle events
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        self.running = False
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            self.running = False
                
                # Update animation
                self.orb.update()
                
                # Render frame
                self.render_frame()
                
                # Control FPS (60)
                self.clock.tick(60)
                
            except Exception as e:
                print(f"Animation error: {e}")
                break
    
    def render_frame(self):
        """Render single frame"""
        try:
            if not self.screen:
                return
            
            # Clear screen (dark semi-transparent)
            self.screen.fill((10, 10, 20))
            
            # Draw orb
            self.orb.draw_to_surface(self.screen)
            
            # Draw text label
            text = self.orb.get_state_text()
            text_surf = self.font.render(text, True, (0, 255, 200))
            text_rect = text_surf.get_rect(
                center=(self.orb.center_x, self.orb.center_y + 150)
            )
            self.screen.blit(text_surf, text_rect)
            
            # Draw FPS counter
            fps_text = self.font.render(
                f"FPS: {self.orb.current_fps:.1f}",
                True,
                (255, 255, 255)
            )
            self.screen.blit(fps_text, (20, 20))
            
            # Update display
            pygame.display.flip()
            
        except Exception as e:
            print(f"Render error: {e}")
    
    def show(self):
        """Show overlay and start animation"""
        self.create_overlay()
        
        # Start animation in main thread (pygame needs this)
        self.animate()
    
    def close(self):
        """Close overlay"""
        self.running = False
        if self.screen:
            pygame.quit()
        self.screen = None
    
    def set_state(self, state):
        """Change orb state"""
        self.orb.state = state
    
    def wait_until_closed(self):
        """Block until overlay is closed (for pygame, just run animate)"""
        pass

if __name__ == "__main__":
    print("ScreenSense AI - Thinking Orb Demo")
    print("Press ESC to close the window")
    print()
    print("Starting in 1920x1080 resolution...")
    
    # Create and show overlay
    overlay = ScreenOverlay(width=1920, height=1080)
    
    try:
        # Run the animation (blocking)
        overlay.show()
    except KeyboardInterrupt:
        print("\n✓ Demo closed")
        overlay.close()
